package com.telusko.quizapp.test;

public abstract class MyAbstractTest {

	public static void main(String[] args) {
		MyAbstractChild   mychild = new MyAbstractChild() ;
		mychild.showcheck();
		mychild.show();
	}

	public abstract void show();

	public Integer get() {
		System.out.println("In Parent getOne");
		return 0;
	};

}

abstract class MyAbstract extends MyAbstractTest {

	public void showcheck() {

		System.out.println("In Parent showcheck");
	};

	public Integer getOne() {
		System.out.println("In Parent getOne");
		return 0;
	};
}

 class MyAbstractChild extends MyAbstractTest {

	public void showcheck() {

		System.out.println("In Child showcheck");
	};

	public Integer getOne() {
		System.out.println("In Child getOne");
		return 0;
	};
	
	public  void show() {
		
		System.out.println("In Child show #");
	};
	
}

/*
 * Note 1: We can not declare an abstract method into an abstract
 * 
 */
